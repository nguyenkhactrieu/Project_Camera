<div id="header">
    <div id="info_admin" style="margin-left: 30px;">
        <!--anh đại diện-->
        <div id="avartar" style="float: left; width: 40px; height: 40px;">
            <img src="" style="margin-top: 5px; border: 1px solid; border-radius: 20px 20px 20px 20px;width: 40px; height: 40px;" alt="" />
        </div>
        <!--ten admin-->
        <div id="name" style="float: left; line-height: 50px;">
            <span style="color:white; padding-left: 20px;"></span>
        </div>
        <!--menu setting-->
        <div id="logout" style="float: left; padding-left: 20px; cursor: pointer;">
            <i id="arow_dow" class="fa fa-caret-down" aria-hidden="true" style=" line-height: 50px;font-size: 20px; color:white"></i>
        </div>
        <!--menu setting-->
        <div id="menu_logout">
            <ul>
                <li>
                    <a href="doi-mat-khau"><i class="fa fa-key" aria-hidden="true"></i>&nbsp Đổi mật khẩu</a>
                </li>
                <li><a href="doi-anh-dai-dien"><i class="fa fa-file-image-o" aria-hidden="true"></i>&nbsp Đổi ảnh đại diện</a></li>
                <li>
                    <a href="index.php?key=thoat"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp Đăng xuất</a>
                </li>
            </ul>
        </div>
    </div>
</div>