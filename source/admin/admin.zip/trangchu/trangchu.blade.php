@extends('admin.index')
@section('content')
<div id="noidung">
    <ul>
        <li id="donhang" class="items">
            <a href="pt/tat-ca-don-hang-0.html" style="display: block;" title="Đơn hàng mới"><i class="fa fa-address-card-o" aria-hidden="true" style="color:green" ></i>
            <hr />
            <span style="font-size: 15px; color:black">Có  đơn hàng mới</span></a>
        </li>
        <li id="users_online" class="items">
            <a href="users.html" title="Tài khoản">
                <i class="fa fa-users" aria-hidden="true" style="color:green"></i>
            <hr />
            <span style="font-size: 15px;color:black">Có  tài khoản</span>
            </a>
        </li>
        <li id="user_lock" class="items">
            <a href="tai-khoan-dang-khoa.html" title="Tài khoản đang bị khóa">
                <i class="fa fa-lock" aria-hidden="true" style="color:red"></i>
                <hr />
                <span style="font-size: 15px;color:black">Có tài khoản đang bị khóa</span>
            </a>
        </li>
        <li id="truycap" class="items">
            <a href="san-pham.html" title="Sản phẩm">
                <i class="fa fa-table" aria-hidden="true" style="color:green"></i>
                <hr />
                <span style="font-size: 15px;color:black">Có  sản phẩm</span>
            </a>
        </li>
        <li id="hethang" class="items">
            <a href="san-pham-sap-het-hang.html" title="Sản phẩm sắp hết hàng">
                <i class="fa fa-cart-arrow-down" aria-hidden="true" style="color:#ff6c00"></i>
                <hr />
                <span style="font-size: 15px;color:black"> Sản phẩm sắp hết hàng</span>
            </a>
        </li>
        <li id="binhluan" class="items">
            <a href="p1/binh-luan-san-pham-0.html" title="Bình luận chưa trả lời">
                <i class="fa fa-comment" aria-hidden="true" style="color:#ff6c00"></i>
                <hr />
                <span style="font-size: 15px;color:black"> Bình luận chưa trả lời</span>
            </a>
        </li>
    </ul>
</div>
@endsection