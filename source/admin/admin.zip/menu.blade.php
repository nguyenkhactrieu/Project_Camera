<div class="menu">
    <ul>
        <li style="background: red"><a href=""><i class="fa fa-home" aria-hidden="true"></i>   &nbsp Trang chủ</a></li>
        <li>
            <a href="#"><i class="fa fa-table" aria-hidden="true" ></i> &nbsp Quản lý Sản phẩm<i class="fa fa-chevron-right muiten " aria-hidden="true" style="line-height: 40px;"></i></a>
            <ul class="sub_menu">
                <li><a href="chung-loai.html">Chủng loại sản phẩm</a></li>
                <li><a href="loai-san-pham.html">Loại sản phẩm</a></li>
                <li><a href="san-pham.html">Sản phẩm</a></li>
            </ul>
        </li>
        <li><a href="users.html"><i class="fa fa-users" aria-hidden="true"></i> &nbsp Quản lý User</a></li>
        <li><a href="don-hang.html"><i class="fa fa-address-card-o" aria-hidden="true"></i> &nbsp Quản lý Đơn hàng</a></li>
        <li><a href="binh-luan-san-pham.html"><i class="fa fa-comments-o" aria-hidden="true"></i> &nbsp Quản lý bình luận</a></li>
        <li><a href="slideshow.html"><i class="fa fa-picture-o" aria-hidden="true"></i> &nbsp Quản lý slideshow</a></li>
    </ul>
</div>
<div class="menu">
    <ul>
        <li style="background: red"><a href="index.php"><i class="fa fa-tachometer" aria-hidden="true"></i>   &nbsp Thống kê</a></li>
        <li><a href="#"><i class="fa fa-users" aria-hidden="true"></i> &nbsp Users<i class="fa fa-chevron-right muiten " aria-hidden="true" style="line-height: 40px;"></i></a>
            <ul class="sub_menu">
                <li><a href="tai-khoan-dang-khoa.html">Users đang bị khóa</a></li>
            </ul>
        </li>
        <li><a href="san-pham-sap-het-hang.html"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>&nbsp Sản phẩm sắp hết hàng</a></li>
    </ul>
</div>